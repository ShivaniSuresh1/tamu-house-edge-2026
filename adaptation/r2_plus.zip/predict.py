"""House Edge entry: recreate test predictions from saved model (no training at run time).
Usage: python predict.py --data /data --out /output/submission.csv
"""
import argparse, csv, sys
from pathlib import Path
import pandas as pd
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from feats import build
from gbm_eval import GBM

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--data", required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--split", default="test"); a = ap.parse_args()
    d = Path(a.data) / a.split
    q = pd.read_csv(d / "queries.csv"); h = pd.read_csv(d / "history.csv")
    X = build(q, h, "query")
    paths = sorted(HERE.glob("model*.json"))  # one model.json, or model_00.json.. for an ensemble (averaged)
    if not paths: raise SystemExit("no model*.json found")
    Ps = []
    for p in paths:
        g = GBM(p)
        Ps.append(g.proba(X[g.cols].to_numpy(float)))
    P = sum(Ps) / len(Ps)
    P = P / P.sum(1, keepdims=True)
    out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["query_id", "p_0", "p_1", "p_2", "p_5", "p_20"])
        for qid, row in sorted(zip(X.query_id, P.tolist())):
            w.writerow([qid] + [repr(float(v)) for v in row])
    if set(X.query_id) != set(q.query_id): raise SystemExit("query mismatch")
    print(f"wrote {len(X)} rows to {out}")

if __name__ == "__main__":
    main()
