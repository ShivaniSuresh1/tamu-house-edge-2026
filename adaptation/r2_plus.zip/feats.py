"""Leak-free feature builder. Every feature at tick t uses only ticks < t.

Works for training (every observed tick t is an example, label = payout at t)
and for queries (t = cutoff). Pure numpy; vectorised per machine via cumsums.
"""
import itertools
import numpy as np
from scipy.signal import lfilter
import pandas as pd

PAYOUTS = [0, 1, 2, 5, 20]
PIDX = {p: i for i, p in enumerate(PAYOUTS)}
TYPES = ["steady", "balanced", "jackpot"]
LAGS = range(1, 9)
PAIRS = list(itertools.combinations(range(1, 9), 2))
HLS = [3, 8, 24, 64]
A = 2.0  # smoothing strength toward machine base rate


def _ew(x, obs, hl, T):
    """EW mean of x over observed ticks < t, for every t in 0..T. Returns (mean, weight)."""
    d = 2 ** (-1.0 / hl)
    num = np.zeros(T + 1); den = np.zeros(T + 1)
    n = m = 0.0
    for t in range(T + 1):
        num[t], den[t] = n, m
        if t < len(x) and obs[t]:
            n = n * d + x[t]; m = m * d + 1.0
        else:
            n *= d; m *= d
    return num / np.maximum(den, 1e-9), den


def ewb(x, hl):
    """EW sum of x over indices strictly before t (len T+1 output for len T+1 input)."""
    d = 2 ** (-1.0 / hl)
    y = lfilter([1.0], [1.0, -d], x)
    return np.concatenate([[0.0], y[:-1]])


def machine_features(pay, T):
    """pay: float array len T (NaN = missing). Returns dict name -> array len T+1 (feature at t)."""
    obs = ~np.isnan(pay)
    win = np.where(obs, (np.nan_to_num(pay) > 0).astype(float), 0.0)
    cls = np.where(obs, np.nan_to_num(pay), -1)
    F = {}
    # cumulative (strictly before t) counts
    def before(a):
        c = np.concatenate([[0.0], np.cumsum(a)])
        return c[:T + 1] if len(c) >= T + 1 else np.pad(c, (0, T + 1 - len(c)), mode="edge")
    n_obs = before(obs.astype(float)); n_win = before(win)
    base = (n_win + 1.0) / (n_obs + 2.0)
    F["n_obs"] = n_obs
    F["base_win"] = base
    padobs = np.concatenate([obs, np.zeros(1, bool)]); padwin = np.concatenate([win, [0.0]])
    # lag states at t (feature): win at t-L (1/0) or -1 missing
    def lagged(arr, L, fill):
        out = np.full(T + 1, fill, dtype=float)
        out[L:] = arr[:T + 1 - L] if len(arr) >= T + 1 - L else np.pad(arr, (0, T + 1 - L - len(arr)), constant_values=fill)[:T + 1 - L]
        return out
    lag_state = {}
    for L in LAGS:
        lo = lagged(padobs.astype(float), L, 0.0)
        lw = lagged(padwin, L, 0.0)
        st = np.where(lo > 0, lw, -1.0)
        lag_state[L] = st
        F[f"lag{L}_win"] = st
        F[f"lag{L}_pay"] = np.where(lo > 0, lagged(np.concatenate([cls, [-1]]).astype(float), L, -1), -1)
    # conditional win rates: P(win_u | state at u-L) using u < t
    obsT = np.concatenate([obs, np.zeros(max(0, T + 1 - len(obs)), bool)])[:T + 1]
    winT = np.concatenate([win, np.zeros(max(0, T + 1 - len(win)))])[:T + 1]
    gaps = []
    for L in LAGS:
        st = lag_state[L]
        rates = {}
        for s in (0.0, 1.0):
            ok = (obsT & (st == s)).astype(float)
            n = np.concatenate([[0.0], np.cumsum(ok)])[:T + 1]
            w = np.concatenate([[0.0], np.cumsum(ok * winT)])[:T + 1]
            rates[s] = (w + A * base) / (n + A)
        cur = np.where(st == 1, rates[1.0], np.where(st == 0, rates[0.0], base))
        F[f"cr{L}"] = cur - base
        g = rates[1.0] - rates[0.0]
        F[f"gap{L}"] = g
        gaps.append(np.abs(g))
    gaps = np.array(gaps)  # 8 x T+1
    crs = np.array([F[f"cr{L}"] for L in LAGS])
    # best single lag (by in-history gap) and its implied shift
    bi = gaps.argmax(0)
    F["best_lag"] = bi + 1.0
    F["best_cr"] = crs[bi, np.arange(T + 1)]
    F["best_gap"] = gaps.max(0)
    # pair cells: pick pair with best in-history fit (chi-ish: weighted variance of cell rates)
    best_score = np.full(T + 1, -1.0); best_pred = np.zeros(T + 1); best_id = np.zeros(T + 1)
    for pid, (a, b) in enumerate(PAIRS):
        sa, sb = lag_state[a], lag_state[b]
        valid = (sa >= 0) & (sb >= 0)
        cell = np.where(valid, sa * 2 + sb, -1)
        score = np.zeros(T + 1); pred = base.copy()
        for c in range(4):
            ok = (obsT & (cell == c)).astype(float)
            n = np.concatenate([[0.0], np.cumsum(ok)])[:T + 1]
            w = np.concatenate([[0.0], np.cumsum(ok * winT)])[:T + 1]
            r = (w + A * base) / (n + A)
            score += n * (r - base) ** 2
            pred = np.where(cell == c, r, pred)
        better = score > best_score
        best_score = np.where(better, score, best_score)
        best_pred = np.where(better, pred, best_pred)
        best_id = np.where(better, pid, best_id)
    F["pair_cr"] = best_pred - base
    F["pair_score"] = best_score / np.maximum(n_obs, 1)
    # explicit (4,7)-style interaction rates are covered by pair selection; also XOR of 7 with others

    # ---- v2: recency-weighted conditional structure (drift / reversal) ----
    for hl in (16, 40):
        egaps = []; ecrs = []
        eb_n = ewb(obsT.astype(float), hl); eb_w = ewb(obsT * winT, hl)
        ebase = (eb_w + 1.0 * base) / (eb_n + 1.0)
        for L in LAGS:
            st = lag_state[L]; r = {}
            for s_ in (0.0, 1.0):
                ok = (obsT & (st == s_)).astype(float)
                r[s_] = (ewb(ok * winT, hl) + A * ebase) / (ewb(ok, hl) + A)
            ecrs.append(np.where(st == 1, r[1.0], np.where(st == 0, r[0.0], ebase)) - ebase)
            egaps.append(r[1.0] - r[0.0])
        ecrs = np.array(ecrs); egaps = np.array(egaps)
        F[f"ebase{hl}"] = ebase
        F[f"ecr_best{hl}"] = ecrs[bi, np.arange(T + 1)]
        F[f"egap_best{hl}"] = egaps[bi, np.arange(T + 1)]
        # sign agreement between recent and long-run gap at best lag (reversal detector)
        F[f"gapflip{hl}"] = egaps[bi, np.arange(T + 1)] * np.array([F[f"gap{L}"] for L in LAGS])[bi, np.arange(T + 1)]
        # recency-weighted best pair
        bs = np.full(T + 1, -1.0); bp = np.zeros(T + 1)
        for (a, b) in PAIRS:
            sa, sb = lag_state[a], lag_state[b]
            cell = np.where((sa >= 0) & (sb >= 0), sa * 2 + sb, -1)
            sc = np.zeros(T + 1); pr = ebase.copy()
            for c in range(4):
                ok = (obsT & (cell == c)).astype(float)
                n = ewb(ok, hl); r = (ewb(ok * winT, hl) + A * ebase) / (n + A)
                sc += n * (r - ebase) ** 2; pr = np.where(cell == c, r, pr)
            bt = sc > bs; bs = np.where(bt, sc, bs); bp = np.where(bt, pr, bp)
        F[f"epair_cr{hl}"] = bp - ebase
        F[f"epair_pred{hl}"] = bp
    # surprise: recent wins minus static-pair prediction (pred at u uses < u; EW over u < t)
    resid = np.where(obsT, winT - best_pred, 0.0)
    for hl in (6, 20):
        F[f"surp{hl}"] = ewb(resid, hl) / np.maximum(ewb(obsT.astype(float), hl), 1e-6)
    F["pair_pred"] = best_pred
    # ---- v4: per-machine online ridge regression of win on lag states + all pair interactions ----
    Z = np.array([lag_state[L] for L in LAGS]).T  # (T+1, 8) in {1,0,-1}
    Z = np.where(Z < 0, 0.0, 2 * Z - 1)            # win +1, loss -1, missing 0
    cols_ = [np.ones(T + 1)] + [Z[:, i] for i in range(8)] + [Z[:, a - 1] * Z[:, b - 1] for a, b in PAIRS]
    Xr = np.array(cols_).T                         # (T+1, 37)
    k = Xr.shape[1]
    o = obsT.astype(float)
    XX = (Xr[:, :, None] * Xr[:, None, :] * o[:, None, None]).reshape(T + 1, -1)
    Xy = Xr * (o * (winT - 0.5))[:, None]
    pen = np.full(k, 1.0); pen[0] = 1e-3
    for tag, hl in (("", None), ("_e40", 40)):
        if hl is None:
            SXX = np.concatenate([np.zeros((1, k * k)), np.cumsum(XX, 0)])[:T + 1]
            SXy = np.concatenate([np.zeros((1, k)), np.cumsum(Xy, 0)])[:T + 1]
        else:
            d = 2 ** (-1.0 / hl)
            SXX = np.concatenate([np.zeros((1, k * k)), lfilter([1.0], [1.0, -d], XX, axis=0)])[:T + 1]
            SXy = np.concatenate([np.zeros((1, k)), lfilter([1.0], [1.0, -d], Xy, axis=0)])[:T + 1]
        for lam in (3.0, 15.0):
            Aa = SXX.reshape(T + 1, k, k) + lam * np.diag(pen)[None]
            beta = np.linalg.solve(Aa, SXy[:, :, None])[:, :, 0]
            F[f"rr{tag}_{int(lam)}"] = np.clip(0.5 + (Xr * beta).sum(1), -0.2, 1.2)
    # recency
    for hl in HLS:
        m, wgt = _ew(win, obs, hl, T)
        F[f"ew{hl}"] = np.where(wgt > 1e-6, m, base)
        F[f"ewn{hl}"] = wgt
    F["ew3_minus_64"] = F["ew3"] - F["ew64"]
    F["ew8_minus_64"] = F["ew8"] - F["ew64"]
    # payout size mix among wins (EW, hl 32) and overall
    for p in (1, 2, 5, 20):
        x = np.where(obs, (np.nan_to_num(pay) == p).astype(float), 0.0)
        m, wgt = _ew(x, obs, 32, T)
        mw, _ = _ew(win, obs, 32, T)
        F[f"size{p}"] = np.where(mw > 1e-6, m / np.maximum(mw, 1e-6), np.nan)
        cw = before(x)
        F[f"cnt_frac{p}"] = (cw + 0.25) / (n_win + 1.0)
    # density of recent observation
    F["obs_last16"] = n_obs - np.concatenate([np.zeros(16), n_obs[:-16]])[:T + 1]
    return F


def build(queries, history, mode, labels=None):
    """mode='ticks': one row per observed tick (label = payout) with t>=16.
       mode='query': one row per query at its cutoff."""
    rows = []
    qi = queries.set_index("machine_id")
    for ep, hg in history.groupby("episode_id", sort=True):
        eq = queries[queries.episode_id == ep]
        T = int(eq.cutoff.max())
        mids = list(eq.machine_id)
        pays = {}
        for m in mids:
            g = hg[hg.machine_id == m]
            a = np.full(T, np.nan)
            g = g[g.tick < T]
            a[g.tick.values] = g.payout.values
            pays[m] = a
        feats = {m: machine_features(pays[m], T) for m in mids}
        # episode-level: mean over OTHER machines of ew8/ew64 and ew diff, lag1 win
        keys = ["ew3", "ew8", "ew64", "ew8_minus_64", "lag1_win", "surp6", "surp20", "gapflip16"]
        tot = {k: sum(np.where(feats[m][k] < -0.5, np.nan, feats[m][k]) if k == "lag1_win" else feats[m][k] for m in mids) for k in keys}
        for m in mids:
            r = qi.loc[m]
            F = feats[m]
            ep_f = {}
            for k in ["ew3", "ew8", "ew64", "ew8_minus_64", "surp6", "surp20", "gapflip16"]:
                ep_f["ep_" + k] = (tot[k] - F[k]) / (len(mids) - 1)
            if mode == "query":
                ts = np.array([int(r.cutoff)])
                ys = None
            else:
                a = pays[m]
                ts = np.where(~np.isnan(a))[0]
                ts = ts[ts >= 16]
                ys = a[ts].astype(int)
            block = {k: v[ts] for k, v in F.items()}
            block.update({k: v[ts] for k, v in ep_f.items()})
            df = pd.DataFrame(block)
            df["type"] = TYPES.index(r.machine_type)
            df["signal"] = int(r.signal)
            df["t"] = ts
            df["episode_id"] = ep
            df["query_id"] = r.query_id
            if ys is not None:
                df["y"] = [PIDX[v] for v in ys]
            rows.append(df)
    return pd.concat(rows, ignore_index=True)


FEATURES = None  # filled by caller: all columns except id/label columns


def feature_cols(df):
    return [c for c in df.columns if c not in ("episode_id", "query_id", "y", "t")]
