# House Edge entry

Recreate: `python predict.py --data /data --out /output/submission.csv`
Built and checked with Python 3.14; dependencies pinned in requirements.txt. No network, no training at run time, deterministic.

Model: per-machine leak-free history statistics (own conditional win rates given payouts at lags 1-8,
best lag-pair cell, recency-weighted versions, surprise vs own pattern, exponentially weighted win rates,
payout-size mix, episode-wide summaries of other machines) -> scikit-learn HistGradientBoostingClassifier (single model.json, or an average of 5 models
model_00..04.json with max_features=0.5 and random_state=0..4)
(5 classes), trained offline on every observed history tick of train + validation, using
only ticks strictly before each label. Trees exported to model.json, evaluated in numpy by gbm_eval.py
(verified identical to sklearn predict_proba). Training code: train.py (in the author's toolkit).
