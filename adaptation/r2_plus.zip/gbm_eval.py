"""numpy evaluator for exported HistGradientBoostingClassifier trees (multiclass softmax)."""
import json, numpy as np
class GBM:
    def __init__(s,path):
        d=json.load(open(path)); s.cols=d["cols"]; s.base=np.array(d["baseline"])
        s.trees=[[{k:np.array(v) for k,v in t.items()} for t in it] for it in d["trees"]]
    def raw(s,X):
        X=np.asarray(X,float); n=len(X); K=len(s.base)
        out=np.tile(s.base,(n,1))
        idx=np.arange(n)
        for it in s.trees:
            for k,t in enumerate(it):
                node=np.zeros(n,int)
                while True:
                    lf=t["leaf"][node]==1
                    if lf.all(): break
                    x=X[idx,np.where(lf,0,t["f"][node])]
                    goleft=np.where(np.isnan(x),t["ml"][node]==1,x<=t["thr"][node])
                    nxt=np.where(goleft,t["l"][node],t["r"][node])
                    node=np.where(lf,node,nxt)
                out[:,k]+=t["v"][node]
        return out
    def proba(s,X):
        r=s.raw(X); r=r-r.max(1,keepdims=True); e=np.exp(r); return e/e.sum(1,keepdims=True)
